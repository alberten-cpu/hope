<h1>Customer Create Sucessfully</h1>
<p>{{$customer->name}}</p>
