@if($view)
    <a href="{{ $view }}" class="btn btn-xs btn-primary"><i
            class="glyphicon glyphicon-edit" role="button"></i> {{__('View')}}</a>
@endif


