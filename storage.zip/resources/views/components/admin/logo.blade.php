<!-- Brand Logo -->
<a href="/" class="brand-link">
    <img src="{{asset('/admin/dist/img/AdminLTELogo.png') }}" alt="AdminLTE Logo"
         class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">{{__(config('app.name'))}}</span>
</a>
